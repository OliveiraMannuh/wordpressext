<div class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h4>Sobre Nós</h4>
                <ul>
                    <li><a href="#">Quem Somos</a></li>
                    <li><a href="#">Nossa Missão</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h4>Recursos</h4>
                <ul>
                    <li><a href="#">Jogos Educativos</a></li>
                    <li><a href="#">Simulados</a></li>
                    <li><a href="#">Flashcards</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h4>Suporte</h4>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Contato</a></li>
                    <li><a href="#">Política de Privacidade</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h4>Siga-nos</h4>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">Instagram</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>