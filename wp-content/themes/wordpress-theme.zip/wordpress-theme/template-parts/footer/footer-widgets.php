<div class="footer-widgets">
    <div class="footer-column">
        <h3>Sobre Nós</h3>
        <ul>
            <li><a href="#">Nossa História</a></li>
            <li><a href="#">Equipe</a></li>
            <li><a href="#">Carreiras</a></li>
        </ul>
    </div>
    <div class="footer-column">
        <h3>Recursos</h3>
        <ul>
            <li><a href="#">Jogos Educativos</a></li>
            <li><a href="#">Simulados</a></li>
            <li><a href="#">Quiz</a></li>
            <li><a href="#">Flashcards</a></li>
        </ul>
    </div>
    <div class="footer-column">
        <h3>Suporte</h3>
        <ul>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Contato</a></li>
            <li><a href="#">Política de Privacidade</a></li>
        </ul>
    </div>
    <div class="footer-column">
        <h3>Siga-nos</h3>
        <ul>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">Instagram</a></li>
        </ul>
    </div>
</div>